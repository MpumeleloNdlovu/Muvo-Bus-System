﻿namespace MuvoBus.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class bus : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Bookings",
                c => new
                    {
                        BookingID = c.Int(nullable: false, identity: true),
                        RouteID = c.Int(nullable: false),
                        BookDate = c.DateTime(nullable: false),
                        ExpiryDate = c.DateTime(nullable: false),
                        UserID = c.String(),
                        FirstName = c.String(),
                        Surname = c.String(),
                        CellNumber = c.String(),
                    })
                .PrimaryKey(t => t.BookingID)
                .ForeignKey("dbo.Routes", t => t.RouteID, cascadeDelete: true)
                .Index(t => t.RouteID);
            
            CreateTable(
                "dbo.Routes",
                c => new
                    {
                        RouteID = c.Int(nullable: false, identity: true),
                        RouteName = c.String(nullable: false),
                        Duration = c.String(),
                        StopId = c.Int(nullable: false),
                        BusID = c.Int(nullable: false),
                        Arrival = c.String(),
                        StandardCost = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.RouteID)
                .ForeignKey("dbo.Buses", t => t.BusID, cascadeDelete: true)
                .ForeignKey("dbo.Stops", t => t.StopId, cascadeDelete: true)
                .Index(t => t.StopId)
                .Index(t => t.BusID);
            
            CreateTable(
                "dbo.Buses",
                c => new
                    {
                        BusID = c.Int(nullable: false, identity: true),
                        MaxSeats = c.Int(nullable: false),
                        BusNumber = c.String(),
                        BusTypeID = c.Int(nullable: false),
                        BusCID = c.Int(nullable: false),
                        CBTID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.BusID)
                .ForeignKey("dbo.BusCompanies", t => t.BusCID, cascadeDelete: true)
                .ForeignKey("dbo.BusTypes", t => t.BusTypeID, cascadeDelete: true)
                .ForeignKey("dbo.CompanyBusTypes", t => t.CBTID, cascadeDelete: true)
                .Index(t => t.BusTypeID)
                .Index(t => t.BusCID)
                .Index(t => t.CBTID);
            
            CreateTable(
                "dbo.BusCompanies",
                c => new
                    {
                        BusCID = c.Int(nullable: false, identity: true),
                        CompanyName = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.BusCID);
            
            CreateTable(
                "dbo.BusTypes",
                c => new
                    {
                        BusTypeID = c.Int(nullable: false, identity: true),
                        BusTypeName = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.BusTypeID);
            
            CreateTable(
                "dbo.CompanyBusTypes",
                c => new
                    {
                        CBTID = c.Int(nullable: false, identity: true),
                        BusCID = c.Int(nullable: false),
                        BusTypeID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.CBTID)
                .ForeignKey("dbo.BusCompanies", t => t.BusCID, cascadeDelete: true)
                .ForeignKey("dbo.BusTypes", t => t.BusTypeID, cascadeDelete: true)
                .Index(t => t.BusCID)
                .Index(t => t.BusTypeID);
            
            CreateTable(
                "dbo.Stops",
                c => new
                    {
                        StopID = c.Int(nullable: false, identity: true),
                        StopName = c.String(),
                        StopAddress = c.String(),
                    })
                .PrimaryKey(t => t.StopID);
            
            CreateTable(
                "dbo.BusDrivers",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        BName = c.String(),
                        BLastName = c.String(),
                        BusCID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.BusCompanies", t => t.BusCID, cascadeDelete: true)
                .Index(t => t.BusCID);
            
            CreateTable(
                "dbo.CardApplications",
                c => new
                    {
                        CardApplicationId = c.Int(nullable: false, identity: true),
                        UserId = c.String(),
                        Status = c.String(),
                        Reason = c.String(),
                        Date = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.CardApplicationId);
            
            CreateTable(
                "dbo.ClientCards",
                c => new
                    {
                        ClientCardId = c.Int(nullable: false, identity: true),
                        UserId = c.String(),
                        ExpireryDate = c.DateTime(nullable: false),
                        LastUsed = c.DateTime(nullable: false),
                        Balance = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Status = c.String(),
                    })
                .PrimaryKey(t => t.ClientCardId);
            
            CreateTable(
                "dbo.DependantAplications",
                c => new
                    {
                        DependantAppId = c.Int(nullable: false, identity: true),
                        UserId = c.String(),
                        DependentId = c.Int(nullable: false),
                        Reason = c.String(),
                        Status = c.String(),
                        Date = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.DependantAppId)
                .ForeignKey("dbo.Dependants", t => t.DependentId, cascadeDelete: true)
                .Index(t => t.DependentId);
            
            CreateTable(
                "dbo.Dependants",
                c => new
                    {
                        DependentId = c.Int(nullable: false, identity: true),
                        FirstName = c.String(nullable: false),
                        LastName = c.String(nullable: false),
                        IdNumber = c.String(nullable: false, maxLength: 13),
                        Age = c.Int(nullable: false),
                        UserId = c.String(),
                    })
                .PrimaryKey(t => t.DependentId);
            
            CreateTable(
                "dbo.DependantCards",
                c => new
                    {
                        DependantCardId = c.Int(nullable: false, identity: true),
                        DependentId = c.Int(nullable: false),
                        ExpireryDate = c.DateTime(nullable: false),
                        LastUsed = c.DateTime(nullable: false),
                        Balance = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Status = c.String(),
                    })
                .PrimaryKey(t => t.DependantCardId)
                .ForeignKey("dbo.Dependants", t => t.DependentId, cascadeDelete: true)
                .Index(t => t.DependentId);
            
            CreateTable(
                "dbo.AspNetRoles",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        Name = c.String(nullable: false, maxLength: 256),
                        Discriminator = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.Name, unique: true, name: "RoleNameIndex");
            
            CreateTable(
                "dbo.AspNetUserRoles",
                c => new
                    {
                        UserId = c.String(nullable: false, maxLength: 128),
                        RoleId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.UserId, t.RoleId })
                .ForeignKey("dbo.AspNetRoles", t => t.RoleId, cascadeDelete: true)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId)
                .Index(t => t.RoleId);
            
            CreateTable(
                "dbo.AspNetUsers",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        FirstName = c.String(),
                        LastName = c.String(),
                        IdNumber = c.String(),
                        Age = c.Int(nullable: false),
                        Email = c.String(maxLength: 256),
                        EmailConfirmed = c.Boolean(nullable: false),
                        PasswordHash = c.String(),
                        SecurityStamp = c.String(),
                        PhoneNumber = c.String(),
                        PhoneNumberConfirmed = c.Boolean(nullable: false),
                        TwoFactorEnabled = c.Boolean(nullable: false),
                        LockoutEndDateUtc = c.DateTime(),
                        LockoutEnabled = c.Boolean(nullable: false),
                        AccessFailedCount = c.Int(nullable: false),
                        UserName = c.String(nullable: false, maxLength: 256),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.UserName, unique: true, name: "UserNameIndex");
            
            CreateTable(
                "dbo.AspNetUserClaims",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        UserId = c.String(nullable: false, maxLength: 128),
                        ClaimType = c.String(),
                        ClaimValue = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.AspNetUserLogins",
                c => new
                    {
                        LoginProvider = c.String(nullable: false, maxLength: 128),
                        ProviderKey = c.String(nullable: false, maxLength: 128),
                        UserId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.LoginProvider, t.ProviderKey, t.UserId })
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AspNetUserRoles", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserLogins", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserClaims", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserRoles", "RoleId", "dbo.AspNetRoles");
            DropForeignKey("dbo.DependantCards", "DependentId", "dbo.Dependants");
            DropForeignKey("dbo.DependantAplications", "DependentId", "dbo.Dependants");
            DropForeignKey("dbo.BusDrivers", "BusCID", "dbo.BusCompanies");
            DropForeignKey("dbo.Bookings", "RouteID", "dbo.Routes");
            DropForeignKey("dbo.Routes", "StopId", "dbo.Stops");
            DropForeignKey("dbo.Routes", "BusID", "dbo.Buses");
            DropForeignKey("dbo.Buses", "CBTID", "dbo.CompanyBusTypes");
            DropForeignKey("dbo.CompanyBusTypes", "BusTypeID", "dbo.BusTypes");
            DropForeignKey("dbo.CompanyBusTypes", "BusCID", "dbo.BusCompanies");
            DropForeignKey("dbo.Buses", "BusTypeID", "dbo.BusTypes");
            DropForeignKey("dbo.Buses", "BusCID", "dbo.BusCompanies");
            DropIndex("dbo.AspNetUserLogins", new[] { "UserId" });
            DropIndex("dbo.AspNetUserClaims", new[] { "UserId" });
            DropIndex("dbo.AspNetUsers", "UserNameIndex");
            DropIndex("dbo.AspNetUserRoles", new[] { "RoleId" });
            DropIndex("dbo.AspNetUserRoles", new[] { "UserId" });
            DropIndex("dbo.AspNetRoles", "RoleNameIndex");
            DropIndex("dbo.DependantCards", new[] { "DependentId" });
            DropIndex("dbo.DependantAplications", new[] { "DependentId" });
            DropIndex("dbo.BusDrivers", new[] { "BusCID" });
            DropIndex("dbo.CompanyBusTypes", new[] { "BusTypeID" });
            DropIndex("dbo.CompanyBusTypes", new[] { "BusCID" });
            DropIndex("dbo.Buses", new[] { "CBTID" });
            DropIndex("dbo.Buses", new[] { "BusCID" });
            DropIndex("dbo.Buses", new[] { "BusTypeID" });
            DropIndex("dbo.Routes", new[] { "BusID" });
            DropIndex("dbo.Routes", new[] { "StopId" });
            DropIndex("dbo.Bookings", new[] { "RouteID" });
            DropTable("dbo.AspNetUserLogins");
            DropTable("dbo.AspNetUserClaims");
            DropTable("dbo.AspNetUsers");
            DropTable("dbo.AspNetUserRoles");
            DropTable("dbo.AspNetRoles");
            DropTable("dbo.DependantCards");
            DropTable("dbo.Dependants");
            DropTable("dbo.DependantAplications");
            DropTable("dbo.ClientCards");
            DropTable("dbo.CardApplications");
            DropTable("dbo.BusDrivers");
            DropTable("dbo.Stops");
            DropTable("dbo.CompanyBusTypes");
            DropTable("dbo.BusTypes");
            DropTable("dbo.BusCompanies");
            DropTable("dbo.Buses");
            DropTable("dbo.Routes");
            DropTable("dbo.Bookings");
        }
    }
}
