﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MuvoBus.Models;
using Microsoft.AspNet.Identity;
namespace MuvoBus.Controllers
{
    [Authorize]
    public class DependantAplicationsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: DependantAplications
        public ActionResult Index()
        {
            var userid = User.Identity.GetUserId();
            var dependantAplications = db.dependantAplications.Where(x=>x.UserId==userid).Include(d => d.Dependant);
            return View(dependantAplications.ToList());
        }

        // GET: DependantAplications/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DependantAplication dependantAplication = db.dependantAplications.Find(id);
            if (dependantAplication == null)
            {
                return HttpNotFound();
            }
            return View(dependantAplication);
        }

        // GET: DependantAplications/Create
        public ActionResult Create()
        {
            var userid = User.Identity.GetUserId();
            ViewBag.DependentId = new SelectList(db.Dependants.Where(x=>x.UserId==userid), "DependentId", "FirstName");
            return View();
        }

        // POST: DependantAplications/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "DependantAppId,UserId,DependentId,Status,Date,Reason")] DependantAplication dependantAplication)
        {
            if (ModelState.IsValid)
            {dependantAplication.UserId = User.Identity.GetUserId();
                dependantAplication.Date = DateTime.Now;
                dependantAplication.Status = "Submitted";
               
                db.dependantAplications.Add(dependantAplication);
                db.SaveChanges();
                return RedirectToAction("CardApplications", "Customer");
            }

            ViewBag.DependentId = new SelectList(db.Dependants, "DependentId", "FirstName", dependantAplication.DependentId);
            return View(dependantAplication);
        }

        // GET: DependantAplications/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DependantAplication dependantAplication = db.dependantAplications.Find(id);
            if (dependantAplication == null)
            {
                return HttpNotFound();
            }
            ViewBag.DependentId = new SelectList(db.Dependants, "DependentId", "FirstName", dependantAplication.DependentId);
            return View(dependantAplication);
        }

        // POST: DependantAplications/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "DependantAppId,UserId,DependentId,Status,Date")] DependantAplication dependantAplication)
        {
            if (ModelState.IsValid)
            {
                db.Entry(dependantAplication).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DependentId = new SelectList(db.Dependants, "DependentId", "FirstName", dependantAplication.DependentId);
            return View(dependantAplication);
        }

        // GET: DependantAplications/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DependantAplication dependantAplication = db.dependantAplications.Find(id);
            if (dependantAplication == null)
            {
                return HttpNotFound();
            }
            return View(dependantAplication);
        }

        // POST: DependantAplications/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            DependantAplication dependantAplication = db.dependantAplications.Find(id);
            db.dependantAplications.Remove(dependantAplication);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
