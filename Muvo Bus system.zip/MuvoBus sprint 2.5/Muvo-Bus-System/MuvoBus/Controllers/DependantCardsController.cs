﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MuvoBus.Models;

namespace MuvoBus.Controllers
{
    public class DependantCardsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: DependantCards
        public ActionResult Index(int Id)
        {
            Session["appId"] = Id;
            var app = db.dependantAplications.Find(Id);
            ViewBag.dependant = db.Dependants.Find(app.DependentId);
            var dependantCards = db.dependantCards.Where(x=>x.DependentId==app.DependentId&& x.Status=="Active").Include(d => d.Dependant);
            return View(dependantCards.ToList());
        }

        // GET: DependantCards/Details/5
        public ActionResult Deactivate(int Id)
        {
            DependantCard dependantCard = db.dependantCards.Find(Id);
            dependantCard.Status = "Unactive";
            db.Entry(dependantCard).State = EntityState.Modified;
            db.SaveChanges();
            int AppId = (int)Session["appId"];
            return RedirectToAction("Index", new { Id = AppId });
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DependantCard dependantCard = db.dependantCards.Find(id);
            if (dependantCard == null)
            {
                return HttpNotFound();
            }
            return View(dependantCard);
        }

        // GET: DependantCards/Create
        public ActionResult Create(int Id)
        {
            db.dependantCards.Add(new DependantCard { DependentId = Id, Balance = 0, ExpireryDate = DateTime.Now.AddYears(5), Status = "Active", LastUsed = DateTime.Now }); 
            db.SaveChanges();
            int AppId = (int)Session["appId"];
            var app = db.dependantAplications.Find(AppId);
            app.Status = "Processed";
            db.Entry(app).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index", new {Id= Id });
        }

       
        // POST: DependantCards/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "DependantCardId,DependentId,ExpireryDate,LastUsed,Balance")] DependantCard dependantCard)
        {
            if (ModelState.IsValid)
            {
                db.dependantCards.Add(dependantCard);
                db.SaveChanges();
               
            }

            ViewBag.DependentId = new SelectList(db.Dependants, "DependentId", "FirstName", dependantCard.DependentId);
            return View(dependantCard);
        }

        // GET: DependantCards/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DependantCard dependantCard = db.dependantCards.Find(id);
            if (dependantCard == null)
            {
                return HttpNotFound();
            }
            ViewBag.DependentId = new SelectList(db.Dependants, "DependentId", "FirstName", dependantCard.DependentId);
            return View(dependantCard);
        }

        // POST: DependantCards/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "DependantCardId,DependentId,ExpireryDate,LastUsed,Balance")] DependantCard dependantCard)
        {
            if (ModelState.IsValid)
            {
                db.Entry(dependantCard).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DependentId = new SelectList(db.Dependants, "DependentId", "FirstName", dependantCard.DependentId);
            return View(dependantCard);
        }

        // GET: DependantCards/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DependantCard dependantCard = db.dependantCards.Find(id);
            if (dependantCard == null)
            {
                return HttpNotFound();
            }
            return View(dependantCard);
        }

        // POST: DependantCards/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            DependantCard dependantCard = db.dependantCards.Find(id);
            db.dependantCards.Remove(dependantCard);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
