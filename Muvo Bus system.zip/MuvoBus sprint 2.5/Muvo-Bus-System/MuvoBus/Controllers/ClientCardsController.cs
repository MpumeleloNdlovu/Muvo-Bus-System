﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MuvoBus.Models;

namespace MuvoBus.Controllers
{
    public class ClientCardsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: ClientCards
        public ActionResult Index(int Id)
        {
            Session["appId"] = Id;
            var app = db.CardApplications.Find(Id);
            ViewBag.user = db.Users.Find(app.UserId);
            return View(db.clientCards.Where(x=>x.UserId==app.UserId&& x.Status=="Active").ToList());
        }

        //DeActivate Card
        public ActionResult Deactivate(int Id)
        {
           var  ClientCard = db.clientCards.Find(Id);
            ClientCard.Status = "Unactive";
            db.Entry(ClientCard).State = EntityState.Modified;
            db.SaveChanges();
            int AppId = (int)Session["appId"];
            return RedirectToAction("Index", new { Id = AppId});
        }
        // GET: ClientCards/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ClientCard clientCard = db.clientCards.Find(id);
            if (clientCard == null)
            {
                return HttpNotFound();
            }
            return View(clientCard);
        }

        // GET: ClientCards/Create
        public ActionResult Create( string UserId)
        {
            db.clientCards.Add(new ClientCard {  UserId = UserId , Balance = 0, ExpireryDate = DateTime.Now.AddYears(5), Status = "Active", LastUsed = DateTime.Now }); ;
            db.SaveChanges();
            int AppId = (int)Session["appId"];
            var app = db.CardApplications.Find(AppId);
            app.Status = "Processed";
            db.Entry(app).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index", new { Id = AppId});
        }

        // POST: ClientCards/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ClientCardId,UserId,ExpireryDate,LastUsed,Balance")] ClientCard clientCard)
        {
            if (ModelState.IsValid)
            {
                db.clientCards.Add(clientCard);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(clientCard);
        }

        // GET: ClientCards/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ClientCard clientCard = db.clientCards.Find(id);
            if (clientCard == null)
            {
                return HttpNotFound();
            }
            return View(clientCard);
        }

        // POST: ClientCards/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ClientCardId,UserId,ExpireryDate,LastUsed,Balance")] ClientCard clientCard)
        {
            if (ModelState.IsValid)
            {
                db.Entry(clientCard).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(clientCard);
        }

        // GET: ClientCards/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ClientCard clientCard = db.clientCards.Find(id);
            if (clientCard == null)
            {
                return HttpNotFound();
            }
            return View(clientCard);
        }

        // POST: ClientCards/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ClientCard clientCard = db.clientCards.Find(id);
            db.clientCards.Remove(clientCard);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
