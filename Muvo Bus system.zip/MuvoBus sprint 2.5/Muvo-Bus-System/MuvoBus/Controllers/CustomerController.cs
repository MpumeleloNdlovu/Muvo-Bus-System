﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MuvoBus.Models;
using MuvoBus.Models.ViewModels;
using Microsoft.AspNet.Identity;
using System.Data;
using System.Data.Entity;

namespace MuvoBus.Controllers
{
    [Authorize]
    public class CustomerController : Controller
    {
        // GET: Customer
        private ApplicationDbContext db = new ApplicationDbContext();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult CardApplications()
        {
            var userid = User.Identity.GetUserId();
            var dependantAplications = db.dependantAplications.Where(x => x.UserId == userid).Include(d => d.Dependant);
            var cards = db.CardApplications.Where(x => x.UserId == userid).ToList();
            return View(new MuvoBus.Models.ViewModels.CardApplications {dependantAplications=dependantAplications.ToList(), CardApplication= cards});
        }
        public ActionResult CreateCard()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateCard(string card)
        {

            if (card== "Dependant")
            {
                return RedirectToAction("Create","DependantAplications");
            }
            else
            {
                return RedirectToAction("Create", "CardApplications");
            }
           
        }
        public ActionResult Mycard()
        {
            var userid = User.Identity.GetUserId();
            var client = db.clientCards.Where(x => x.UserId == userid && x.Status == "Active" || x.Status== "Deactivated").ToList();
            var list = new List<DependantCard>();
            foreach(var  i in db.Dependants.Where(x => x.UserId == userid).ToList())
            {
                foreach(var card in db.dependantCards.Where(x => x.DependentId == i.DependentId && x.Status == "Active" || x.Status == "Deactivated"))
                {
                    list.Add(card);
                }
            }
            return View(new Cards { clientCards=client, dependantCards=list });

        }
        public ActionResult Deactivated(int Id)
        {
            DependantCard dependantCard = db.dependantCards.Find(Id);
            dependantCard.Status = "Deactivated";
            db.Entry(dependantCard).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Mycard");
        }
        public ActionResult Deactivate(int Id)
        {
            var ClientCard = db.clientCards.Find(Id);
            ClientCard.Status = "Deactivated";
            db.Entry(ClientCard).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Mycard");
        }
    }
}