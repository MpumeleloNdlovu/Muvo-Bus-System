﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MuvoBus.Models;
using Microsoft.AspNet.Identity;

namespace MuvoBus.Controllers
{
    [Authorize]
    public class CardApplicationsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: CardApplications
        public ActionResult Index()
        {
            return View(db.CardApplications.ToList());
        }

        // GET: CardApplications/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CardApplications cardApplications = db.CardApplications.Find(id);
            if (cardApplications == null)
            {
                return HttpNotFound();
            }
            return View(cardApplications);
        }

        // GET: CardApplications/Create
        public ActionResult Create()
        {

            return View();
        }
        // POST: CardApplications/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CardApplicationId,UserId,Status,Date, Reason")] CardApplications cardApplications)
        {
            if (ModelState.IsValid)
            {
                db.CardApplications.Add(new CardApplications { Reason=cardApplications.Reason, Date = DateTime.Now, Status = "Submitted", UserId = User.Identity.GetUserId() });
                db.SaveChanges();
                return RedirectToAction("CardApplications","Customer");
            }

            return View(cardApplications);
        }

        // GET: CardApplications/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CardApplications cardApplications = db.CardApplications.Find(id);
            if (cardApplications == null)
            {
                return HttpNotFound();
            }
            return View(cardApplications);
        }

        // POST: CardApplications/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CardApplicationId,UserId,Status,Date")] CardApplications cardApplications)
        {
            if (ModelState.IsValid)
            {
                db.Entry(cardApplications).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(cardApplications);
        }

        // GET: CardApplications/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CardApplications cardApplications = db.CardApplications.Find(id);
            if (cardApplications == null)
            {
                return HttpNotFound();
            }
            return View(cardApplications);
        }

        // POST: CardApplications/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            CardApplications cardApplications = db.CardApplications.Find(id);
            db.CardApplications.Remove(cardApplications);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
