﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MuvoBus.Models;

namespace MuvoBus.Controllers
{
    public class StopsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Stops
        public ActionResult Index()
        {
            return View(db.Stops.ToList());
        }

        // GET: Stops/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Stops stops = db.Stops.Find(id);
            if (stops == null)
            {
                return HttpNotFound();
            }
            return View(stops);
        }

        // GET: Stops/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Stops/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "StopID,StopName,StopAddress")] Stops stops)
        {
            if (ModelState.IsValid)
            {
                db.Stops.Add(stops);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(stops);
        }

        // GET: Stops/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Stops stops = db.Stops.Find(id);
            if (stops == null)
            {
                return HttpNotFound();
            }
            return View(stops);
        }

        // POST: Stops/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "StopID,StopName,StopAddress")] Stops stops)
        {
            if (ModelState.IsValid)
            {
                db.Entry(stops).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(stops);
        }

        // GET: Stops/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Stops stops = db.Stops.Find(id);
            if (stops == null)
            {
                return HttpNotFound();
            }
            return View(stops);
        }

        // POST: Stops/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Stops stops = db.Stops.Find(id);
            db.Stops.Remove(stops);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
