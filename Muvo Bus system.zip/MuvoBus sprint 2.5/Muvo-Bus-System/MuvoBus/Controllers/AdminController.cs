﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MuvoBus.Models;
using MuvoBus.Models.ViewModels;
using Microsoft.AspNet.Identity;
using System.Data;
using System.Data.Entity;

namespace MuvoBus.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        private ApplicationDbContext db = new ApplicationDbContext();

        public ActionResult Index()
        {
         
            var dependantAplications = db.dependantAplications.Where(x => x.Status =="Submitted" ).Include(d => d.Dependant);
            var cards = db.CardApplications.Where(x => x.Status == "Submitted").ToList();
            return View(new MuvoBus.Models.ViewModels.CardApplications { dependantAplications = dependantAplications.ToList(), CardApplication = cards });
        }
    }
}