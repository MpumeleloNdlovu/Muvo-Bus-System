﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MuvoBus.Models;

namespace MuvoBus.Controllers
{
    public class BusesController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Buses
        public ActionResult Index()
        {
            var buses = db.Buses.Include(b => b.Buscompany).Include(b => b.bustype).Include(b => b.companybustype);
            return View(buses.ToList());
        }

        // GET: Buses/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bus bus = db.Buses.Find(id);
            if (bus == null)
            {
                return HttpNotFound();
            }
            return View(bus);
        }

        // GET: Buses/Create
        public ActionResult Create()
        {
            ViewBag.BusCID = new SelectList(db.BusCompanies, "BusCID", "CompanyName");
            ViewBag.BusTypeID = new SelectList(db.BusTypes, "BusTypeID", "BusTypeName");
           
            return View();
        }

        // POST: Buses/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BusID,MaxSeats,BusNumber,CBTID,BusTypeID,BusCID")] Bus bus)
        {
            if (ModelState.IsValid)
            {
                bus.CBTID = 1;
                db.Buses.Add(bus);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.BusCID = new SelectList(db.BusCompanies, "BusCID", "CompanyName", bus.BusCID);
            ViewBag.BusTypeID = new SelectList(db.BusTypes, "BusTypeID", "BusTypeName", bus.BusTypeID);
           
            return View(bus);
        }

        // GET: Buses/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bus bus = db.Buses.Find(id);
            if (bus == null)
            {
                return HttpNotFound();
            }
            ViewBag.BusCID = new SelectList(db.BusCompanies, "BusCID", "CompanyName", bus.BusCID);
            ViewBag.BusTypeID = new SelectList(db.BusTypes, "BusTypeID", "BusTypeName", bus.BusTypeID);
           // ViewBag.CBTID = new SelectList(db.CompanyBusTypes, "CBTID", "CBTID", bus.CBTID);
            return View(bus);
        }

        // POST: Buses/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BusID,MaxSeats,BusNumber,CBTID,BusTypeID,BusCID")] Bus bus)
        {
            if (ModelState.IsValid)
            {
                bus.CBTID = 1;

                db.Entry(bus).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.BusCID = new SelectList(db.BusCompanies, "BusCID", "CompanyName", bus.BusCID);
            ViewBag.BusTypeID = new SelectList(db.BusTypes, "BusTypeID", "BusTypeName", bus.BusTypeID);
            ViewBag.CBTID = new SelectList(db.CompanyBusTypes, "CBTID", "CBTID", bus.CBTID);
            return View(bus);
        }

        // GET: Buses/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Bus bus = db.Buses.Find(id);
            if (bus == null)
            {
                return HttpNotFound();
            }
            return View(bus);
        }

        // POST: Buses/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Bus bus = db.Buses.Find(id);
            db.Buses.Remove(bus);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
