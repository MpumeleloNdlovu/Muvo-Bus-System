﻿using MuvoBus.Models;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace MuvoBus.Controllers
{
    public class EmailController : Controller
    {
        // GET: Email
        // GET: Email
        public ActionResult Contact()
        {
            return View();

        }

        [HttpPost]

        public async Task<ActionResult> Contact(Email model)
        {
            if (ModelState.IsValid)
            {
                var body = "<p>Email From: {0} ({1})</p><p>Message:</p><p>{2}</p>";
                var message = new MailMessage();
                message.To.Add(new MailAddress("muvobus@gmail.com")); //replace with valid value
                message.Subject = "Your email subject";
                message.Body = string.Format(body, model.FromName, model.FromEmail, model.Message);
                message.IsBodyHtml = true;

                using (var smtp = new SmtpClient())
                {
                    await smtp.SendMailAsync(message);
                    return RedirectToAction("Sent");
                }
            }
            return View(model);
        }
        public ActionResult Sent()
        {
            return View();
        }
    }
}