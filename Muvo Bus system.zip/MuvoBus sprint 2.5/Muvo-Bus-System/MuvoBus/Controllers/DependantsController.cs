﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MuvoBus.Models;
using Microsoft.AspNet.Identity;

namespace MuvoBus.Controllers
{
    [Authorize]
    public class DependantsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Dependants
        public ActionResult Index()
        {
            var userid = User.Identity.GetUserId();
            return View(db.Dependants.Where(x=>x.UserId==userid).ToList());
        }

        // GET: Dependants/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Dependant dependant = db.Dependants.Find(id);
            if (dependant == null)
            {
                return HttpNotFound();
            }
            return View(dependant);
        }

        // GET: Dependants/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Dependants/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "DependentId,FirstName,LastName,IdNumber,Age")] Dependant dependant)
        {
            if (ModelState.IsValid)
            {
                dependant.UserId = User.Identity.GetUserId();
                db.Dependants.Add(dependant);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(dependant);
        }

        // GET: Dependants/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Dependant dependant = db.Dependants.Find(id);
            if (dependant == null)
            {
                return HttpNotFound();
            }
            return View(dependant);
        }

        // POST: Dependants/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "DependentId,FirstName,LastName,IdNumber,Age,UserId")] Dependant dependant)
        {
            if (ModelState.IsValid)
            {
                db.Entry(dependant).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(dependant);
        }

        // GET: Dependants/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Dependant dependant = db.Dependants.Find(id);
            if (dependant == null)
            {
                return HttpNotFound();
            }
            return View(dependant);
        }

        // POST: Dependants/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Dependant dependant = db.Dependants.Find(id);
            db.Dependants.Remove(dependant);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
