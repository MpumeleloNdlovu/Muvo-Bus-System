﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MuvoBus.Models;

namespace MuvoBus.Controllers
{
    public class CompanyBusTypesController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: CompanyBusTypes
        public ActionResult Index()
        {
            var companyBusTypes = db.CompanyBusTypes.Include(c => c.buscompany).Include(c => c.bustype);
            return View(companyBusTypes.ToList());
        }

        // GET: CompanyBusTypes/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CompanyBusType companyBusType = db.CompanyBusTypes.Find(id);
            if (companyBusType == null)
            {
                return HttpNotFound();
            }
            return View(companyBusType);
        }

        // GET: CompanyBusTypes/Create
        public ActionResult Create()
        {
            ViewBag.BusCID = new SelectList(db.BusCompanies, "BusCID", "CompanyName");
            ViewBag.BusTypeID = new SelectList(db.BusTypes, "BusTypeID", "BusTypeName");
            return View();
        }

        // POST: CompanyBusTypes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CBTID,BusCID,BusTypeID")] CompanyBusType companyBusType)
        {
            if (ModelState.IsValid)
            {
                db.CompanyBusTypes.Add(companyBusType);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.BusCID = new SelectList(db.BusCompanies, "BusCID", "CompanyName", companyBusType.BusCID);
            ViewBag.BusTypeID = new SelectList(db.BusTypes, "BusTypeID", "BusTypeName", companyBusType.BusTypeID);
            return View(companyBusType);
        }

        // GET: CompanyBusTypes/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CompanyBusType companyBusType = db.CompanyBusTypes.Find(id);
            if (companyBusType == null)
            {
                return HttpNotFound();
            }
            ViewBag.BusCID = new SelectList(db.BusCompanies, "BusCID", "CompanyName", companyBusType.BusCID);
            ViewBag.BusTypeID = new SelectList(db.BusTypes, "BusTypeID", "BusTypeName", companyBusType.BusTypeID);
            return View(companyBusType);
        }

        // POST: CompanyBusTypes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CBTID,BusCID,BusTypeID")] CompanyBusType companyBusType)
        {
            if (ModelState.IsValid)
            {
                db.Entry(companyBusType).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.BusCID = new SelectList(db.BusCompanies, "BusCID", "CompanyName", companyBusType.BusCID);
            ViewBag.BusTypeID = new SelectList(db.BusTypes, "BusTypeID", "BusTypeName", companyBusType.BusTypeID);
            return View(companyBusType);
        }

        // GET: CompanyBusTypes/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CompanyBusType companyBusType = db.CompanyBusTypes.Find(id);
            if (companyBusType == null)
            {
                return HttpNotFound();
            }
            return View(companyBusType);
        }

        // POST: CompanyBusTypes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            CompanyBusType companyBusType = db.CompanyBusTypes.Find(id);
            db.CompanyBusTypes.Remove(companyBusType);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
