﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MuvoBus.Models
{
    public class Booking
    {
        [Key]
        public int BookingID { get; set; }
        public virtual Route Route { get; set; }
        public int RouteID { get; set; }
        public DateTime BookDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string UserID { get; set; }
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string CellNumber { get; set; }


    }
}