﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace MuvoBus.Models
{
    public class ClientCard
    {
        [Key]
        public int ClientCardId { get; set; }
        public string UserId { get; set; }
        public DateTime ExpireryDate { get; set; }
        public DateTime LastUsed { get; set; }
        public decimal Balance { get; set; }
        public string Status { get; set; }
    }
}