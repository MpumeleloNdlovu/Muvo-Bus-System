﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MuvoBus.Models;

namespace MuvoBus.Models.ViewModels
{
    public class CardApplications
    {
        public List<DependantAplication> dependantAplications { get; set; }
        public List<MuvoBus.Models.CardApplications>  CardApplication { get; set; }
    }
}