﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MuvoBus.Models;
namespace MuvoBus.Models.ViewModels
{
    public class Cards
    {
        public List<ClientCard>  clientCards { get; set; }
        public List<DependantCard>  dependantCards { get; set; }
    }
}