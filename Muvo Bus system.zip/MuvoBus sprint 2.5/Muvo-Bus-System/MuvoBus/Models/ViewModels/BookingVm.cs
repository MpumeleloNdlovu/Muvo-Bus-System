﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MuvoBus.Models.ViewModels
{
    public class BookingVm
    {
        public string Arrival { get; set; }
        public int DependentId { get; set; }
        public string Type { get; set; }
        public string Return { get; set; }
        public int Age { get; set; }
        public DateTime BookDate { get; set; }
        public Booking  Booking { get; set; }


    }
}