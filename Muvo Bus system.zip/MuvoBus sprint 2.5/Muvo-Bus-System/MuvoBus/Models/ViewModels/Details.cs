﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MuvoBus.Models;
namespace MuvoBus.Models.ViewModels
{
    public class Details
    {
        public Booking  booking { get; set; }
        public Route  route { get; set; }
    }
}