﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MuvoBus.Models.ViewModels
{
    public class busbookingVm
    {
        public int RouteID { get; set; }
       
        public   decimal  Discount{ get; set; }
        public decimal BasicCost { get; set; }
        public virtual Route Route { get; set; }
        public Booking Booking { get; set; }
        public string UserType(int age)
        {
            string capture="";
            if (age > 0 && age < 12)
            {
                capture = "Child";
            }
            if (age > 12 && age < 19)
            {
                capture = "Teen";
            }
            if (age > 19 && age < 35)
            {
                capture = "Youth";
            }
            if (age > 35 && age < 50)
            {
                capture = "Adult";
            }
            if (age > 50 )
            {
                capture = "Pensioner";
            }
            return capture;
        }
        public decimal CalcDiscount(string age)
        {
            decimal capture = 0;
            if (age == "Child")
            {
                capture =90;
            }
            if (age == "Teen")
            {
                capture =40;
            }
            if (age =="Youth")
            {
                capture = 10;
            }
            if (age == "Adult")
            {
                capture = 0;
            }
            if (age == "Pensioner")
            {
                capture = 50;
            }
            return capture;
        }
        public decimal GetDiscount(decimal percent , decimal Cost)
        {
            return (Cost-(Cost*(percent/100)));
        }
        public decimal ReturnDiscount(int Age, decimal Cost)
        {
            string user = UserType(Age);
            decimal percent = CalcDiscount(user);
            return GetDiscount(percent,Cost);
        }
    }
}