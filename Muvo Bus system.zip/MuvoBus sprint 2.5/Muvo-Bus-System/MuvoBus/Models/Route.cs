﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MuvoBus.Models
{
    public class Route
    {
        [Key]
        public int RouteID { get; set; }
        [Required]
        [Display(Name ="Route Name")]
        public string RouteName { get; set; }
        public string Duration { get; set; }
        public virtual Stops Stop { get; set; }
        public int StopId { get; set; }
        public virtual Bus Bus { get; set; }
        public int BusID { get; set; }
        public string Arrival { get; set; }
        public decimal StandardCost { get; set; }



        
       
    }
}