﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MuvoBus.Models
{
    public class DependantAplication
    {
        [Key]
        public int DependantAppId { get; set; }
        public string UserId { get; set; }
       
        public int DependentId { get; set; }
        public string Reason { get; set; }
        public string Status { get; set; }
        public DateTime Date { get; set; }
        public virtual Dependant Dependant { get; set; }
    }
}