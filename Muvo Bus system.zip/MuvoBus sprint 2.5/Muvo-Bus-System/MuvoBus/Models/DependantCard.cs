﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MuvoBus.Models
{
    public class DependantCard
    {
        [Key]
        public int DependantCardId { get; set; }
        public int DependentId { get; set; }
        public DateTime ExpireryDate { get; set; }
        public DateTime LastUsed { get; set; }
        public decimal Balance { get; set; }
        public string Status { get; set; }
        public virtual   Dependant Dependant { get; set; }
    }
}