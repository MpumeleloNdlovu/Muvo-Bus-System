﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace MuvoBus.Models
{
    public class BusDriver
    {
        [Key]
        public int ID { get; set; }
        public string BName { get; set; }
        public string BLastName { get; set; }
        public virtual BusCompany Buscompany { get; set; }
        public int BusCID { get; set; }
    }
}