﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Routing;
using Microsoft.Owin.Security;
using System.Data.SqlTypes;

namespace MuvoBus.Models
{
    public class Bus
    {
        [Key]
        public int BusID { get; set; }
        [Display(Name = "Maxiumum seats per bus")]
        public int MaxSeats { get; set; }
       
        public string BusNumber { get; set; } 
        public virtual BusType bustype { get; set; }
        public int BusTypeID { get; set; }

        public virtual BusCompany Buscompany {get;set;}
        public int BusCID { get; set; }
        public virtual CompanyBusType companybustype { get; set; }
        public int CBTID { get; set; }



    }
}