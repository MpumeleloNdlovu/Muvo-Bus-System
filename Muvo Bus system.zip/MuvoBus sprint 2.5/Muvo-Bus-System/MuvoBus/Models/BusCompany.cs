﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MuvoBus.Models
{
    public class BusCompany
    {
        [Key]
        public int BusCID { get; set; }
        [Required]
        public string CompanyName { get; set; }

    }
}