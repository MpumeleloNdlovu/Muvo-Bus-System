﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Microsoft.Owin.Security;

namespace MuvoBus.Models
{
    public class BusType
    {
        [Key]
        public int BusTypeID { get; set; }
        
        [Required]
       public string BusTypeName { get; set; }
   
        
    }
}