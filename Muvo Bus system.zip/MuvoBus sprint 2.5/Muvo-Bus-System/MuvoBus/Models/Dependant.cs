﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MuvoBus.Models
{
    public class Dependant
    {
        [Key]
        public int DependentId { get; set; }
        [Required]
        [RegularExpression("^([a-zA-Z0-9 .&'-]+)$", ErrorMessage = "Characters are not allowed")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        [Required]
        [Display(Name = "Last Name")]
        [RegularExpression("^([a-zA-Z0-9 .&'-]+)$", ErrorMessage = "Characters are not allowed")]
        public string LastName { get; set; }
        [Required]
        [MaxLength(13),MinLength(13)]
        [Display(Name = "ID Number")]
        public string IdNumber { get; set; }
        [Required]
        [Display(Name = "Age")]
        public int Age { get; set; }
        public string UserId { get; set; }
    }
}