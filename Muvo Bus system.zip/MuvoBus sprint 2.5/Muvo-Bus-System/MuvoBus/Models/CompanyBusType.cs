﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MuvoBus.Models
{
    public class CompanyBusType
    {
     [Key]
     public int CBTID { get; set; }
        public virtual BusCompany buscompany { get; set; }
        public int BusCID { get; set; }
       
         public virtual BusType bustype { get; set; }
        public int BusTypeID { get; set; }
    }
}