﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MuvoBus.Models
{
    public class Stops
    {
        [Key]
        public int StopID { get; set; }
        public string StopName { get; set; }
        public string StopAddress { get; set; }
    }
}