﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MuvoBus.Models
{
    public class CardApplications
    {
        [Key]
        public int CardApplicationId { get; set; }
        public string UserId { get; set; }
        public string Status { get; set; }
        public string Reason { get; set; }
        public DateTime  Date { get; set; }

    }
}