﻿using Microsoft.Owin;
using MuvoBus.Models;
using Owin;

[assembly: OwinStartupAttribute(typeof(MuvoBus.Startup))]
namespace MuvoBus
{
    public partial class Startup
    {
        ApplicationDbContext db = new ApplicationDbContext();
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
            CreateRole();
            CreateUser();
        }
    }
}
